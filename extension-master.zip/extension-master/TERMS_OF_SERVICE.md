# Terms of Service

This exists because... you need one to register an app with Roblox. More relevant to you, precious reader, is probably the [privacy policy](https://roblox.plus/about/privacy-policy).

This is a minimal effort of providing a terms of service.

This extension, and [website](https://roblox.plus/login) are provided as-is. I make guarnatees of nothing. If a feature stops working it is possible it may never be fixed. I work on this extension, and make features for the fun of it, and because I use those features myself. Enjoy them while they work, and while they last. Or don't. This extension is published on the chrome store because I wanted to share my creation, and allow others to benefit from the features while they work.

I own nothing of you, or your data. The extension is open source, and found on [GitHub](https://github.com/roblox-plus/extension). Please, take the code, do whatever you want with it.. except for republish it as your own. I do not give permission for the extension to be republished on other platforms, but if you want to modify it and run it locally, by all means.. have at it.

That is all.
