import { default as getUnreadMessageCount } from './getUnreadMessageCount';

// To ensure the webpack service loader can discover the methods: import it, then export it again.
export { getUnreadMessageCount };
