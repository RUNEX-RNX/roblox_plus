import { default as isAuthenticatedUserFollowing } from './isAuthenticatedUserFollowing';

// To ensure the webpack service loader can discover the methods: import it, then export it again.
export { isAuthenticatedUserFollowing };
