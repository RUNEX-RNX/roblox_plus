const container = document.getElementById('game-detail-page');

const placeId = Number(container?.dataset.placeId);

export { placeId };
