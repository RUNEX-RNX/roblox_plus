import load from './load';
import populate from './populate';

export { load, populate };
