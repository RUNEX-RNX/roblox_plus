# Roblox+ Premium

**Roblox+ Premium is not the same as Roblox Premium.** Roblox+ Premium has existed since before Roblox renamed builders club -> premium. Buying [Roblox+ Premium](https://www.roblox.com/games/258257446/Roblox-Hub) **does not** give you [Roblox Premium](https://www.roblox.com/premium/membership).

This extension provides some features behind a paid subscription. By having a private server active for [this place](https://www.roblox.com/games/258257446/Roblox-Hub), some extra features will be unlocked in the extension.

Besides a subset of the settings which can only be enabled with Roblox+ Premium, the only other notable feature included with Roblox+ Premium is the [transactions page](https://roblox.plus/transactions).

This is all subject to change in the future. I do my best to keep any premium features working, but sometimes they break. Sorry.

If you find the extension useful, and you would like to support me for creating it, the best way to do that is by having a [private server subscription](https://www.roblox.com/games/258257446/Roblox-Hub). And if you don't want to, that's fine. It's a free extension for the most part, enjoy!
