# extension-service-loader

This webpack loader exists to ensure that all services in the services directory get put into the global scope.
This for ease of testing.
