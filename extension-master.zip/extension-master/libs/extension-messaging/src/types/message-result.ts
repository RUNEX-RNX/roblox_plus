// The internal result of processing a message.
type MessageResult = {
  success: boolean;
  data: string;
};

export default MessageResult;
