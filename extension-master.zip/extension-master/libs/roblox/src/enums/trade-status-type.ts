enum TradeStatusType {
  Inbound = 'Inbound',
  Outbound = 'Outbound',
  Completed = 'Completed',
  Inactive = 'Inactive',
}

export default TradeStatusType;
