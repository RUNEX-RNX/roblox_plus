# roblox

This module should eventually be moved to [roblox-plus/roblox-npm](https://github.com/roblox-plus/roblox-npm), and published to [npmjs.org](https://www.npmjs.com/package/roblox).

What is published there now is not this module.
