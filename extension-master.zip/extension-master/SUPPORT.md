# Support

I make no guarantees on actually publishing any fixes, or feature requests. But I do try to keep track of what the issues are, and what people want. If you have a bug report, or feature request, you can post it via [GitHub](https://github.com/roblox-plus/extension/issues). This is how I keep track of all of these things. Thanks!
