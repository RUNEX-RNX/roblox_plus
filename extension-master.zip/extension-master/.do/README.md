# :whale: DigitalOcean App Platform

From what I can tell of this directory.. it's not actually used when you try to create a DigitalOcean App. Which is unfortunate, and time consuming.

I ended up creating an app manually, and then going back and uploading the [app.yaml](./app.yaml) file afterwards, when the manual configuration failed.
